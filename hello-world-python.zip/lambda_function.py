from __future__ import print_function

import psycopg2

print('Loading function')

conn_string = "dbname='dev' port='5439' user='sfadmin' password='oYEZAngsWW8xy2qV'" \
    "host='analytics.cu3sn2bs305w.us-east-1.redshift.amazonaws.com'"

def lambda_handler(event, context):
    clean_first_click()
    return "finish"  # Echo back the first key value
    #raise Exception('Something went wrong')

def clean_first_click():
    print ("Connecting to database\n        ->%s" % (conn_string))
    conn = psycopg2.connect(conn_string)
    cursor = conn.cursor()
    query = "update clickstream "\
            "set apache_visit_id = " \
            "replace(replace(regexp_substr(setcookie, 'apache_visit_id=([^;]+);'),'apache_visit_id=', ''), ';', '') "\
            "where apache_visit_id = '-' and setcookie != '-'"
    cursor.execute(query)
    conn.commit()
    conn.close()